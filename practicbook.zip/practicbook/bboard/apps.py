from django.apps import AppConfig


class BboardConfig(AppConfig):
    name = 'bboard'
    verbose_name = 'Доска объявлений' # название раздела приложения в админке
