# from django.contrib import admin
# from .models import Spare, Machine
#
#
# class MachineAdmin(admin.ModelAdmin):
#     list_display = ('name',)
#     list_display_links = ('name',)
#     search_fields = ('name',)
#
#
# admin.site.register(Spare)
# admin.site.register(Machine, MachineAdmin)
