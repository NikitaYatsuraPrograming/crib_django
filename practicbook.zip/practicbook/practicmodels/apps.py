from django.apps import AppConfig


class PracticmodelsConfig(AppConfig):
    name = 'practicmodels'
